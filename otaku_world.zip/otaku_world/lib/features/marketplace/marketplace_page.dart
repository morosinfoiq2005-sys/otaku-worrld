import 'package:flutter/material.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/neon_background.dart';
import '../../core/widgets/phase_placeholder.dart';

class MarketplacePage extends StatelessWidget {
  const MarketplacePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: Text(context.tr('sec_market'))),
      body: const NeonBackground(
        child: PhasePlaceholder(
          icon: Icons.storefront_rounded,
          titleKey: 'sec_market',
          descKey: 'desc_market',
          phase: 7,
          featureKeys: ['f_mkt_1', 'f_mkt_2', 'f_mkt_3', 'f_mkt_4'],
          accent: AppColors.neonPurple,
        ),
      ),
    );
  }
}
