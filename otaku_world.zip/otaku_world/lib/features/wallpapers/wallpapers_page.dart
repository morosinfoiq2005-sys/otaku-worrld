import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/widgets/phase_placeholder.dart';

class WallpapersPage extends StatelessWidget {
  const WallpapersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PhasePlaceholder(
      icon: Icons.wallpaper_rounded,
      titleKey: 'sec_wallpapers',
      descKey: 'desc_wallpapers',
      phase: 2,
      featureKeys: ['f_wall_1', 'f_wall_2', 'f_wall_3', 'f_wall_4', 'f_wall_5', 'f_wall_6'],
      accent: AppColors.neonPurple,
    );
  }
}
