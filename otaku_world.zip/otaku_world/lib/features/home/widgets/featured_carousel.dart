import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/data/sample_data.dart';
import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/generative_art.dart';
import '../../../core/widgets/neon_card.dart';
import '../../../core/widgets/sample_badge.dart';

class FeaturedCarousel extends StatefulWidget {
  const FeaturedCarousel({super.key});

  @override
  State<FeaturedCarousel> createState() => _FeaturedCarouselState();
}

class _FeaturedCarouselState extends State<FeaturedCarousel> {
  final PageController _controller = PageController(viewportFraction: 0.74);
  int _index = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 250,
          child: PageView.builder(
            controller: _controller,
            itemCount: sampleWallpapers.length,
            onPageChanged: (int i) => setState(() => _index = i),
            itemBuilder: (BuildContext context, int i) {
              return AnimatedBuilder(
                animation: _controller,
                builder: (BuildContext context, Widget? child) {
                  double page = _index.toDouble();
                  if (_controller.hasClients &&
                      _controller.position.haveDimensions) {
                    page = _controller.page ?? page;
                  }
                  final double distance =
                      (page - i).abs().clamp(0.0, 1.0).toDouble();
                  return Transform.scale(
                    scale: 1 - distance * 0.1,
                    child: child,
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: _WallpaperCard(item: sampleWallpapers[i]),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (int i = 0; i < sampleWallpapers.length; i++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: i == _index ? 22 : 7,
                height: 7,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: i == _index
                      ? AppColors.electricBlue
                      : AppColors.textSecondary.withAlpha(90),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class _WallpaperCard extends StatelessWidget {
  const _WallpaperCard({required this.item});

  final SampleItem item;

  @override
  Widget build(BuildContext context) {
    return NeonCard(
      padding: EdgeInsets.zero,
      semanticLabel: item.title,
      onTap: () => context.go('/wallpapers'),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            GenerativeArt(seed: item.seed, borderRadius: 0),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xCC000000)],
                ),
              ),
            ),
            const PositionedDirectional(top: 10, end: 10, child: SampleBadge()),
            PositionedDirectional(
              bottom: 14,
              start: 14,
              end: 14,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    context.tr(item.tagKey),
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.electricBlue,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
