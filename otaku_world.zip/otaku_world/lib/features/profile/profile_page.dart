import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/fade_slide_in.dart';
import '../../core/widgets/neon_card.dart';
import '../../core/widgets/section_header.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final Locale locale = ref.watch(localeProvider);

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          FadeSlideIn(
            child: NeonCard(
              child: Row(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: AppColors.neonGradient,
                    ),
                    child: const Icon(
                      Icons.person_rounded,
                      size: 34,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          context.tr('guest'),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          context.tr('guest_sub'),
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SectionHeader(title: context.tr('language')),
          FadeSlideIn(
            delay: 80,
            child: NeonCard(
              glowColor: AppColors.electricBlue,
              child: SizedBox(
                width: double.infinity,
                child: SegmentedButton<String>(
                  segments: const [
                    ButtonSegment<String>(value: 'ar', label: Text('العربية')),
                    ButtonSegment<String>(value: 'en', label: Text('English')),
                  ],
                  selected: {locale.languageCode},
                  onSelectionChanged: (Set<String> selection) {
                    ref
                        .read(localeProvider.notifier)
                        .setLocale(Locale(selection.first));
                  },
                ),
              ),
            ),
          ),
          SectionHeader(title: context.tr('backend_status')),
          FadeSlideIn(
            delay: 120,
            child: NeonCard(
              glowColor: AppColors.gold,
              child: Row(
                children: [
                  const Icon(Icons.cloud_off_rounded, color: AppColors.gold),
                  const SizedBox(width: 12),
                  Expanded(child: Text(context.tr('backend_not_connected'))),
                ],
              ),
            ),
          ),
          SectionHeader(title: context.tr('about')),
          FadeSlideIn(
            delay: 160,
            child: NeonCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.info_outline_rounded,
                        color: AppColors.electricBlue,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        '${context.tr('version')}: ${context.tr('version_value')}',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    context.tr('about_text'),
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
