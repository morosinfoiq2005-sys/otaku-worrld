import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/neon_background.dart';

class MainShell extends StatelessWidget {
  const MainShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(child: navigationShell),
      bottomNavigationBar: _NeonNavBar(
        currentIndex: navigationShell.currentIndex,
        onSelected: (int index) {
          navigationShell.goBranch(
            index,
            initialLocation: index == navigationShell.currentIndex,
          );
        },
      ),
    );
  }
}

class _NavDestination {
  const _NavDestination(this.icon, this.labelKey);

  final IconData icon;
  final String labelKey;
}

const List<_NavDestination> _destinations = [
  _NavDestination(Icons.home_rounded, 'nav_home'),
  _NavDestination(Icons.wallpaper_rounded, 'nav_wallpapers'),
  _NavDestination(Icons.movie_filter_rounded, 'nav_anime'),
  _NavDestination(Icons.emoji_events_rounded, 'nav_rewards'),
  _NavDestination(Icons.person_rounded, 'nav_profile'),
];

class _NeonNavBar extends StatelessWidget {
  const _NeonNavBar({required this.currentIndex, required this.onSelected});

  final int currentIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          top: BorderSide(color: AppColors.neonPurple.withAlpha(90)),
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.neonPurple.withAlpha(40),
            blurRadius: 24,
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 68,
          child: Row(
            children: [
              for (int i = 0; i < _destinations.length; i++)
                Expanded(
                  child: _NavItem(
                    destination: _destinations[i],
                    selected: i == currentIndex,
                    onTap: () => onSelected(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.destination,
    required this.selected,
    required this.onTap,
  });

  final _NavDestination destination;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final String label = context.tr(destination.labelKey);
    final Color color =
        selected ? AppColors.electricBlue : AppColors.textSecondary;

    return Semantics(
      label: label,
      button: true,
      selected: selected,
      child: InkResponse(
        onTap: onTap,
        radius: 36,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: selected
                    ? AppColors.electricBlue.withAlpha(36)
                    : Colors.transparent,
                boxShadow: selected
                    ? [
                        BoxShadow(
                          color: AppColors.electricBlue.withAlpha(60),
                          blurRadius: 14,
                        ),
                      ]
                    : const [],
              ),
              child: Icon(destination.icon, color: color, size: 24),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
