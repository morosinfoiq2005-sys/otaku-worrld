import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/widgets/phase_placeholder.dart';

class RewardsPage extends StatelessWidget {
  const RewardsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PhasePlaceholder(
      icon: Icons.emoji_events_rounded,
      titleKey: 'sec_rewards',
      descKey: 'desc_rewards',
      phase: 5,
      featureKeys: ['f_rew_1', 'f_rew_2', 'f_rew_3', 'f_rew_4', 'f_rew_5', 'f_rew_6'],
      accent: AppColors.gold,
    );
  }
}
