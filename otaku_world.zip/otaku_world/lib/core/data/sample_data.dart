/// Local SAMPLE data used only to show the layout in Phase 1.
/// All titles are fictional. Real data arrives in later phases.
class SampleItem {
  const SampleItem({
    required this.title,
    required this.tagKey,
    required this.seed,
  });

  final String title;
  final String tagKey;
  final int seed;
}

const List<SampleItem> sampleWallpapers = [
  SampleItem(title: 'Neon Samurai', tagKey: 'tag_4k', seed: 3),
  SampleItem(title: 'Midnight Circuit', tagKey: 'tag_amoled', seed: 8),
  SampleItem(title: 'Pixel Arena', tagKey: 'tag_gaming', seed: 12),
  SampleItem(title: 'Violet Skyline', tagKey: 'tag_anime', seed: 21),
  SampleItem(title: 'Electric Dawn', tagKey: 'tag_4k', seed: 34),
];

const List<SampleItem> sampleAnime = [
  SampleItem(title: 'Neon Blade', tagKey: 'tag_action', seed: 41),
  SampleItem(title: 'Astral Academy', tagKey: 'tag_fantasy', seed: 52),
  SampleItem(title: 'Cyber Ronin', tagKey: 'tag_scifi', seed: 63),
  SampleItem(title: 'Moonlit Guild', tagKey: 'tag_fantasy', seed: 74),
];

const List<SampleItem> sampleThemes = [
  SampleItem(title: 'Cyber Violet', tagKey: 'tag_neon', seed: 85),
  SampleItem(title: 'Soft Void', tagKey: 'tag_minimal', seed: 96),
  SampleItem(title: 'Gold Circuit', tagKey: 'tag_pack', seed: 107),
];

const List<SampleItem> sampleCommunity = [
  SampleItem(title: '@sample_creator', tagKey: 'tag_artwork', seed: 118),
  SampleItem(title: '@neon_artist', tagKey: 'tag_artwork', seed: 129),
  SampleItem(title: '@pixel_dreamer', tagKey: 'tag_artwork', seed: 140),
];

const List<SampleItem> sampleMarket = [
  SampleItem(title: 'Neon Pack Vol.1', tagKey: 'tag_pack', seed: 151),
  SampleItem(title: 'Dark Wave Set', tagKey: 'tag_4k', seed: 162),
  SampleItem(title: 'Golden Hour Pack', tagKey: 'tag_pack', seed: 173),
];
