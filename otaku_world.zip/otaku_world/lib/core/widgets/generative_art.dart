import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Original generative artwork (no external images, no licensing issues).
/// Used as a placeholder until real licensed content is added.
class GenerativeArt extends StatelessWidget {
  const GenerativeArt({
    super.key,
    required this.seed,
    this.borderRadius = 18,
    this.child,
  });

  final int seed;
  final double borderRadius;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: CustomPaint(
        painter: _ArtPainter(seed),
        child: child ?? const SizedBox.expand(),
      ),
    );
  }
}

class _ArtPainter extends CustomPainter {
  _ArtPainter(this.seed);

  final int seed;

  static const List<List<Color>> _palettes = [
    [Color(0xFF14082E), Color(0xFFA24BFF), Color(0xFF00D1FF)],
    [Color(0xFF05122B), Color(0xFF00D1FF), Color(0xFFFF3DA5)],
    [Color(0xFF1A0A24), Color(0xFFFF3DA5), Color(0xFFFFC857)],
    [Color(0xFF07160F), Color(0xFF2DE2A6), Color(0xFFA24BFF)],
    [Color(0xFF120A1F), Color(0xFFFFC857), Color(0xFFA24BFF)],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final math.Random rnd = math.Random(seed);
    final List<Color> p = _palettes[seed.abs() % _palettes.length];
    final Rect rect = Offset.zero & size;

    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [p[0], Color.lerp(p[0], p[1], 0.35)!],
        ).createShader(rect),
    );

    for (int i = 0; i < 3; i++) {
      final Offset c = Offset(
        rnd.nextDouble() * size.width,
        rnd.nextDouble() * size.height,
      );
      final double r = (0.35 + rnd.nextDouble() * 0.4) * size.longestSide;
      final Color color = p[1 + i % 2];
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = RadialGradient(
            colors: [color.withAlpha(170), color.withAlpha(0)],
          ).createShader(Rect.fromCircle(center: c, radius: r)),
      );
    }

    final Paint line = Paint()
      ..color = Colors.white.withAlpha(14)
      ..strokeWidth = 1;
    const double step = 28;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), line);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), line);
    }
  }

  @override
  bool shouldRepaint(covariant _ArtPainter oldDelegate) {
    return oldDelegate.seed != seed;
  }
}
