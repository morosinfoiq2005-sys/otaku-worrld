import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Dark cyberpunk backdrop with soft neon glows.
class NeonBackground extends StatelessWidget {
  const NeonBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: AppColors.background),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(-0.9, -1.0),
              radius: 1.3,
              colors: [
                AppColors.neonPurple.withAlpha(60),
                AppColors.neonPurple.withAlpha(0),
              ],
            ),
          ),
        ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(1.0, 0.9),
              radius: 1.2,
              colors: [
                AppColors.electricBlue.withAlpha(36),
                AppColors.electricBlue.withAlpha(0),
              ],
            ),
          ),
        ),
        child,
      ],
    );
  }
}
