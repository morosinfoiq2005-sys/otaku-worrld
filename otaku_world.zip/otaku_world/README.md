# OTAKU WORLD

Your Anime. Your Style. Your Rewards.

Flutter (Android first) - Arabic RTL + English - Neon Cyberpunk dark theme.

## Status: Phase 1 (foundation)

Done in Phase 1:
- Project structure (feature-first), Riverpod state, GoRouter navigation
- Neon Cyberpunk theme, Arabic/English localization with RTL
- Bottom navigation: Home, Wallpapers, Anime, Rewards, Profile
- Home screen, language switch (saved on device)
- Placeholder pages for every planned section (clearly marked, no fake data)

NOT connected yet (by design): Firebase, APIs, payments. See roadmap phases 2-9.

Rewards policy: there is NO cash withdrawal feature in this app.

## Roadmap
2 Wallpapers - 3 Themes Studio - 4 Anime & Cinema - 5 Rewards - 6 Community
7 Creator Marketplace - 8 Firebase backend + admin security - 9 Testing and release

## Build (no laptop needed)
Use the GitHub Actions workflow "Build APK" (see instructions given with the project).
